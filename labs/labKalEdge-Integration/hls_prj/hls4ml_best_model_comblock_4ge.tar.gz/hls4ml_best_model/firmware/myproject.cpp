#include <iostream>

#include "myproject.h"
#include "parameters.h"

void myproject(
    input_t dense_15_input[N_INPUT_1_1],
    result_t layer7_out[N_LAYER_6]
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS ARRAY_RESHAPE variable=dense_15_input complete dim=0
    #pragma HLS ARRAY_PARTITION variable=layer7_out complete dim=0
    #pragma HLS INTERFACE ap_vld port=dense_15_input,layer7_out 
    #pragma HLS PIPELINE 

#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        // hls-fpga-machine-learning insert load weights
        nnet::load_weights_from_txt<dense_15_weight_t, 1288>(w2, "w2.txt");
        nnet::load_weights_from_txt<dense_15_bias_t, 8>(b2, "b2.txt");
        nnet::load_weights_from_txt<dense_16_weight_t, 32>(w4, "w4.txt");
        nnet::load_weights_from_txt<dense_16_bias_t, 4>(b4, "b4.txt");
        nnet::load_weights_from_txt<dense_17_weight_t, 8>(w6, "w6.txt");
        nnet::load_weights_from_txt<dense_17_bias_t, 2>(b6, "b6.txt");
        loaded_weights = true;
    }
#endif

    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    layer2_t layer2_out[N_LAYER_2];
    #pragma HLS ARRAY_PARTITION variable=layer2_out complete dim=0
    nnet::dense<input_t, layer2_t, config2>(dense_15_input, layer2_out, w2, b2); // dense_15

    layer3_t layer3_out[N_LAYER_2];
    #pragma HLS ARRAY_PARTITION variable=layer3_out complete dim=0
    nnet::relu<layer2_t, layer3_t, relu_config3>(layer2_out, layer3_out); // dense_15_relu

    layer4_t layer4_out[N_LAYER_4];
    #pragma HLS ARRAY_PARTITION variable=layer4_out complete dim=0
    nnet::dense<layer3_t, layer4_t, config4>(layer3_out, layer4_out, w4, b4); // dense_16

    layer5_t layer5_out[N_LAYER_4];
    #pragma HLS ARRAY_PARTITION variable=layer5_out complete dim=0
    nnet::relu<layer4_t, layer5_t, relu_config5>(layer4_out, layer5_out); // dense_16_relu

    layer6_t layer6_out[N_LAYER_6];
    #pragma HLS ARRAY_PARTITION variable=layer6_out complete dim=0
    nnet::dense<layer5_t, layer6_t, config6>(layer5_out, layer6_out, w6, b6); // dense_17

    nnet::softmax<layer6_t, result_t, softmax_config7>(layer6_out, layer7_out); // dense_17_softmax

}
