//Numpy array shape [8]
//Min -0.035609658808
//Max 0.436134755611
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
dense_15_bias_t b2[8];
#else
dense_15_bias_t b2[8] = {0.3327894211, 0.3258681595, -0.0356096588, 0.4279629588, 0.3474647105, 0.3424028158, 0.1001574025, 0.4361347556};
#endif

#endif
