//Numpy array shape [4, 2]
//Min -0.955996692181
//Max 1.144347071648
//Number of zeros 0

#ifndef W6_H_
#define W6_H_

#ifndef __SYNTHESIS__
dense_17_weight_t w6[8];
#else
dense_17_weight_t w6[8] = {0.8500496745, -0.9559966922, -0.5803650618, 1.0602921247, -0.3770166337, 0.8727315068, -0.4974007905, 1.1443470716};
#endif

#endif
