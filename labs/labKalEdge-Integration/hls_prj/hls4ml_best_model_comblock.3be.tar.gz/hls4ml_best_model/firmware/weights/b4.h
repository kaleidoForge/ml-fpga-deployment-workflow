//Numpy array shape [4]
//Min -0.141977623105
//Max 0.549421548843
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
dense_16_bias_t b4[4];
#else
dense_16_bias_t b4[4] = {0.5494215488, -0.1419776231, 0.0123516452, -0.0530298613};
#endif

#endif
