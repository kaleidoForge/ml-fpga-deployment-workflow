//Numpy array shape [2]
//Min -0.437754243612
//Max 0.437753379345
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
dense_17_bias_t b6[2];
#else
dense_17_bias_t b6[2] = {0.4377533793, -0.4377542436};
#endif

#endif
