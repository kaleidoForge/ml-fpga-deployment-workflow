
#include "myproject_bincls_axilite.h"
#include "myproject.h"

void myproject_bincls_axilite(
    hls::stream<axis_t> &s_axis_in,
    int *result
) {
    #pragma HLS INTERFACE axis port=s_axis_in
    #pragma HLS INTERFACE ap_vld port=result
    #pragma HLS INTERFACE ap_ctrl_hs port=return

    input_t in_arr[N_INPUT_1_1];
#pragma HLS ARRAY_PARTITION variable=in_arr complete dim=1

READ_IN:
    for (int i = 0; i < N_INPUT_1_1; i++) {
    #pragma HLS PIPELINE II=1
        axis_t din = s_axis_in.read();
        in_arr[i] = axis_to_fixed<16,6>(din);
    }

    result_t out_arr[N_LAYER_6];
#pragma HLS ARRAY_PARTITION variable=out_arr complete dim=1

    myproject(in_arr, out_arr);

    int tmpVal = 0;
    if (out_arr[0] > out_arr[1]) tmpVal = 0; else tmpVal = 1;
    *result = tmpVal;
}
